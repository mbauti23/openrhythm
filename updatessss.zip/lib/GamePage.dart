import 'dart:math';
import 'dart:ui';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart' show Colors, runApp;
import 'package:flutter/material.dart';
import 'game.dart';
import 'package:flame/components/component.dart';
import 'package:flame/components/animation_component.dart';
import 'package:flame/flame.dart';
import 'package:flame/text_config.dart';
import 'package:flame/position.dart';
import 'dart:async';
import 'dart:io';


const SPEED = 400.0;
const CRATE_SIZE_LENGTH = 104.0;
const NOTE_SIZE_LENGTH = CRATE_SIZE_LENGTH / 2;
const NOTE_SIZE_HEIGHT = 62.0;
const BOX_SIZE_HEIGHT = 92.0;
const MISS_DEDUCTION = 0;

StreamSubscription periodicSub;


var resolution = 192;
var currentBPM = 120000;
var currentTS = 4;

//
var seconds = 0.0;
var notes;
var times1 = 0;
var previousNote12 = 0;
var previousNote22 = 0;
bool paused = false;

List noteList;

TextConfig textConfig = TextConfig(
  color: Colors.white,
  fontSize: 48.0,
  fontFamily: 'Halo',
);

class GamePage extends StatelessWidget{

  BuildContext context1;
  MyGame game;

  Future<bool> _onWillPop() {

    game.pause();

    return showDialog(
      context: context1,
      barrierDismissible: false,
      builder: (context1) => new Theme(
      data: Theme.of(context1).copyWith(dialogBackgroundColor: Colors.black),
        child: AlertDialog(
        title: new Text('Paused.'),
        content: new Text('Do you want to exit the Game?',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              letterSpacing: 5,
              fontSize: 20,
              fontWeight: FontWeight.w800,
              fontFamily: 'Neris',
              decoration: TextDecoration.none,)),
        actions: <Widget>[
          new FlatButton(
            child: new Text("No",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  letterSpacing: 2,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Neris',
                  decoration: TextDecoration.none,)),
            color: Colors.deepPurpleAccent,
            onPressed: ()
            {
            Navigator.of(context1).pop(false);
            game.resume();
            }
          ),
          new FlatButton(
            color: Colors.green,
            onPressed: () {
              Navigator.of(context1).pop(true);
              periodicSub = new Stream.periodic(const Duration(milliseconds: 1000)).take(1).listen((_) {
                return true;
              }
              );
            },
            child: new Text("Yes",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  letterSpacing: 2,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Neris',
                  decoration: TextDecoration.none,)),
          ),
        ],
      ),
    ) ?? false,
    );
  }

  @override
  Widget build(BuildContext context){
    context1 = context;
    Flame.images.loadAll(['explosion.png', 'crate.png', 'one_box-01.png', 'two_box-01.png', 'three_box-01.png', 'four_box-01.png',
    'five_box-01.png', 'six_box-01.png', 'white_box-01.png']);
     game = new MyGame();
    Flame.util.addGestureRecognizer(new MultiTapGestureRecognizer()
      ..onTapDown = (int pointer, TapDownDetails evt) => game.input(evt.globalPosition));
    return new WillPopScope(
        onWillPop: _onWillPop,
        child: game.widget
        );
  }
}


class MyGame extends BaseGame {
  double creationTimer = 0.000000;
  var alreadyRendered = false;

  @override
  void render(Canvas canvas) {

    if (!alreadyRendered) {

      add(new OneBox());
      add(new TwoBox());
      add(new ThreeBox());
      add(new FourBox());
      add(new FiveBox());
      add(new SixBox());

    }

    super.render(canvas);
    String text = points.toString();
    textConfig.render(
        canvas, text, Position((size.width / 2) - (text.length * 12.5), 16));
    alreadyRendered = true;
  }

  @override
  void update(double t) {

    creationTimer += t;
    if (creationTimer >= .35) {
      creationTimer = 0.0;
      var rng = new Random();
      var theone = rng.nextInt(6) + 1;
      if (theone == 1) {
        add(new OneNote());
        add(new TwoNote());
      }
      else if (theone == 2) {
        add(new OneNote());
        add(new ThreeNote());
      }
      else if (theone == 3) {
        add(new TwoNote());
        add(new ThreeNote());
      }
      else if (theone == 4) {
        add(new FourNote());
        add(new FiveNote());
      }
      else if (theone == 5) {
        add(new FourNote());
        add(new SixNote());
      }
      else if (theone == 6) {
        add(new FiveNote());
        add(new SixNote());
      }
    }
    super.update(t);
  }

  void input(Offset position) {

    var bottomNoteY2 = size.height / 2 + (BOX_SIZE_HEIGHT + 50);
    var bottomNoteY1 = size.height / 2;
    var topNoteY2 = size.height / 2 - (BOX_SIZE_HEIGHT + 50);
    var topNoteY1 = size.height / 2 + (BOX_SIZE_HEIGHT / 2);

    components.forEach((component) {
      if (!(component is OneNote) && !(component is TwoNote) && !(component is ThreeNote) && !(component is FourNote) &&
          !(component is FiveNote) && !(component is SixNote)
          && !(component is OneBox) && !(component is TwoBox) && !(component is ThreeBox) &&
          !(component is FourBox) && !(component is FiveBox) && !(component is SixBox)){
        return;
      }

      if(component is OneNote) {
        OneNote greenNote = component as OneNote;
        bool remove = ((position >= Offset(((size.width / 6.0) - (CRATE_SIZE_LENGTH / 2)), topNoteY2))
            && (position < Offset(((size.width / 6.0) + (CRATE_SIZE_LENGTH / 2)), topNoteY1))
            && (greenNote.y  >= topNoteY2)
            && (greenNote.y  < topNoteY1));
        if (remove) {
          greenNote.explode = true;
          add(new Explosion(greenNote));
          //Flame.audio.play('explosion.mp3');
          points += 1;
          return;
        }
      }

      if(component is TwoNote) {
        TwoNote blueNote = component as TwoNote;
        bool remove = ((position >= Offset(((size.width / 2.0) - (CRATE_SIZE_LENGTH / 2)), topNoteY2))
            && (position < Offset(((size.width / 2.0) + (CRATE_SIZE_LENGTH / 2)), topNoteY1))
            && (blueNote.y  >= topNoteY2)
            && (blueNote.y  < topNoteY1));
        if (remove) {
          blueNote.explode = true;
          add(new Explosion(blueNote));
          //Flame.audio.play('explosion.mp3');
          points += 1;
          return;
        }
      }

      if(component is ThreeNote) {
        ThreeNote orangeNote = component as ThreeNote;
        bool remove = ((position >= Offset(((size.width - (size.width / 6.0)) - (CRATE_SIZE_LENGTH / 2)), topNoteY2))
            && (position < Offset(((size.width - (size.width / 6.0)) + (CRATE_SIZE_LENGTH / 2)), topNoteY1))
            && (orangeNote.y  >= topNoteY2)
            && (orangeNote.y < topNoteY1));
        if (remove) {
          orangeNote.explode = true;
          add(new Explosion(orangeNote));
          //Flame.audio.play('explosion.mp3');
          points += 1;
          return;
        }
      }

      if(component is FourNote ) {
        FourNote greenNote = component as FourNote;
        bool remove = ((position >= Offset(((size.width / 6.0) - (CRATE_SIZE_LENGTH / 2)), bottomNoteY1))
            && (position < Offset(((size.width / 6.0) + (CRATE_SIZE_LENGTH / 2)), bottomNoteY2))
            && (greenNote.y  >= bottomNoteY1)
            && (greenNote.y  < bottomNoteY2));
        if (remove) {
          greenNote.explode = true;
          add(new Explosion(greenNote));
          //Flame.audio.play('explosion.mp3');
          points += 1;
          return;
        }
      }

      if(component is FiveNote) {
        FiveNote blueNote = component as FiveNote;
        bool remove = ((position >= Offset(((size.width / 2.0) - (CRATE_SIZE_LENGTH / 2)), bottomNoteY1))
            && (position < Offset(((size.width / 2.0) + (CRATE_SIZE_LENGTH / 2)), bottomNoteY2))
            && (blueNote.y  >= bottomNoteY1)
            && (blueNote.y  < bottomNoteY2));
        if (remove) {
          blueNote.explode = true;
          add(new Explosion(blueNote));
          //Flame.audio.play('explosion.mp3');
          points += 1;
          return;
        }
      }

      if(component is SixNote) {
        SixNote orangeNote = component as SixNote;
        bool remove = ((position >= Offset(((size.width - (size.width / 6.0)) - (CRATE_SIZE_LENGTH / 2)), bottomNoteY1))
            && (position < Offset(((size.width - (size.width / 6.0)) + (CRATE_SIZE_LENGTH / 2)), bottomNoteY2))
            && (orangeNote.y  >= bottomNoteY1)
            && (orangeNote.y < bottomNoteY2));
        if (remove) {
          orangeNote.explode = true;
          add(new Explosion(orangeNote));
          //Flame.audio.play('explosion.mp3');
          points += 1;
          return;
        }
      }
    });

  }
}

//todo------------------------------------OneBox-----------------------------

class OneBox extends SpriteComponent {
  bool explode = false;
  double maxY;

  OneBox() : super.rectangle(CRATE_SIZE_LENGTH, BOX_SIZE_HEIGHT, 'one_box-01.png');

  @override
  void resize(Size size) {
    this.x = ((size.width / 6.0) - (CRATE_SIZE_LENGTH / 2));
    this.y = size.height / 2 + (BOX_SIZE_HEIGHT / 2) + 2;
  }
}

//todo------------------------------------TwoBox-----------------------------

class TwoBox extends SpriteComponent {
  bool explode = false;
  double maxY;

  TwoBox() : super.rectangle(CRATE_SIZE_LENGTH, BOX_SIZE_HEIGHT, 'two_box-01.png');

  @override
  void resize(Size size) {
    this.x = ((size.width / 2.0) - (CRATE_SIZE_LENGTH / 2));
    this.y = size.height / 2 + (BOX_SIZE_HEIGHT / 2) + 2;
  }
}

//todo------------------------------------ThreeBox---------------------------

class ThreeBox extends SpriteComponent {
  bool explode = false;
  double maxY;

  ThreeBox() : super.rectangle(CRATE_SIZE_LENGTH, BOX_SIZE_HEIGHT, 'three_box-01.png');

  @override
  void resize(Size size) {
    this.x = (size.width - (size.width / 6.0) - (CRATE_SIZE_LENGTH / 2));
    this.y = size.height / 2 + (BOX_SIZE_HEIGHT / 2) + 2;
  }
}

//todo------------------------------------FourBox----------------------------

class FourBox extends SpriteComponent {
  bool explode = false;
  double maxY;

  FourBox() : super.rectangle(CRATE_SIZE_LENGTH, BOX_SIZE_HEIGHT, 'four_box-01.png');

  @override
  void resize(Size size) {
    this.x = ((size.width / 6.0) - (CRATE_SIZE_LENGTH / 2));
    this.y = size.height / 2 - (BOX_SIZE_HEIGHT / 2) - 2;
  }
}

//todo------------------------------------FiveBox----------------------------

class FiveBox extends SpriteComponent {
  bool explode = false;
  double maxY;

  FiveBox() : super.rectangle(CRATE_SIZE_LENGTH, BOX_SIZE_HEIGHT, 'five_box-01.png');

  @override
  void resize(Size size) {
    this.x = ((size.width / 2.0) - (CRATE_SIZE_LENGTH / 2));
    this.y = size.height / 2 - (BOX_SIZE_HEIGHT / 2) - 2 ;
  }
}

//todo------------------------------------SixBox----------------------------

class SixBox extends SpriteComponent {
  bool explode = false;
  double maxY;

  SixBox() : super.rectangle(CRATE_SIZE_LENGTH, BOX_SIZE_HEIGHT,'six_box-01.png');

  @override
  void resize(Size size) {
    this.x = (size.width - (size.width / 6.0) - (CRATE_SIZE_LENGTH / 2));
    this.y = size.height / 2 - (BOX_SIZE_HEIGHT / 2) - 2;
  }
}

//todo------------------------------------FIRST NOTE------------------------------------

class OneNote extends SpriteComponent {
  bool explode = false;
  double maxY;

  OneNote() : super.rectangle(NOTE_SIZE_LENGTH, NOTE_SIZE_HEIGHT, 'white_box_blue-01.png');

  @override
  void update(double t) {
    y += t * SPEED;
  }

  @override
  bool destroy() {
    if (explode) {
      return true;
    }
    if (y == null || maxY == null) {
      return false;
    }
    bool destroy = y >= maxY;
    if (destroy) {
      //points -= MISS_DEDUCTION;
      //Flame.audio.play('miss.mp3');
    }
    return destroy;
  }

  @override
  void resize(Size size) {
    this.x = ((size.width / 6.0) - (NOTE_SIZE_LENGTH / 2));
    this.y = 40.0;
    this.maxY = (size.height / 2) - (NOTE_SIZE_LENGTH / 2) + 4;
  }
}

//todo------------------------------------SECOND NOTE----------------------------------

class TwoNote extends SpriteComponent {
  bool explode = false;
  double maxY;

  TwoNote() : super.rectangle(NOTE_SIZE_LENGTH, NOTE_SIZE_HEIGHT, 'white_box_purple-01.png');

  @override
  void update(double t) {
    y += t * SPEED;
  }

  @override
  bool destroy() {
    if (explode) {
      return true;
    }
    if (y == null || maxY == null) {
      return false;
    }
    bool destroy = y >= maxY;
    if (destroy) {
      //points -= MISS_DEDUCTION;
      //Flame.audio.play('miss.mp3');
    }
    return destroy;
  }

  @override
  void resize(Size size) {
    this.x = ((size.width / 2.0) - (NOTE_SIZE_LENGTH / 2));
    this.y = 40.0;
    this.maxY = (size.height / 2) - (NOTE_SIZE_LENGTH / 2) + 4;
  }
}

//todo------------------------------------THIRD NOTE-----------------------------------

class ThreeNote extends SpriteComponent {
  bool explode = false;
  double maxY;

  ThreeNote() : super.rectangle(NOTE_SIZE_LENGTH, NOTE_SIZE_HEIGHT, 'white_box_orange-01.png');

  @override
  void update(double t) {
    y += t * SPEED;
  }

  @override
  bool destroy() {
    if (explode) {
      return true;
    }
    if (y == null || maxY == null) {
      return false;
    }
    bool destroy = y >= maxY;
    if (destroy) {
      //points -= MISS_DEDUCTION;
      //Flame.audio.play('miss.mp3');
    }
    return destroy;
  }

  @override
  void resize(Size size) {
    this.x = (size.width - (size.width / 6.0) - (NOTE_SIZE_LENGTH / 2));
    this.y = 40.0;
    this.maxY = (size.height / 2) - (NOTE_SIZE_LENGTH / 2) + 4;
  }
}

//todo------------------------------------FOURTH NOTE----------------------------------

class FourNote extends SpriteComponent {
  bool explode = false;
  double maxY;

  FourNote() : super.rectangle(NOTE_SIZE_LENGTH, NOTE_SIZE_HEIGHT, 'white_box_green-01.png');

  @override
  void update(double t) {
    y -= t * SPEED;
  }

  @override
  bool destroy() {
    if (explode) {
      return true;
    }
    if (y == null || maxY == null) {
      return false;
    }
    bool destroy = y <= maxY + NOTE_SIZE_LENGTH;
    if (destroy) {
      //points -= MISS_DEDUCTION;
      //Flame.audio.play('miss.mp3');
    }
    return destroy;
  }

  @override
  void resize(Size size) {
    this.x = ((size.width / 6.0) - (NOTE_SIZE_LENGTH / 2));
    this.y = size.height;
    this.maxY = (size.height / 2) - 4;
  }
}

//todo------------------------------------FIFTH NOTE-----------------------------------

class FiveNote extends SpriteComponent {

  bool explode = false;
  double maxY;

  FiveNote() : super.rectangle(NOTE_SIZE_LENGTH, NOTE_SIZE_HEIGHT, 'white_box_red-01.png');

  @override
  void update(double t) {
    y -= t * SPEED;
  }

  @override
  bool destroy() {
    if (explode) {
      return true;
    }
    if (y == null || maxY == null) {
      return false;
    }
    bool destroy = y <= maxY + NOTE_SIZE_LENGTH;
    if (destroy) {
      //points -= MISS_DEDUCTION;
      //Flame.audio.play('miss.mp3');
    }
    return destroy;
  }

  @override
  void resize(Size size) {
    this.x = ((size.width / 2.0) - (NOTE_SIZE_LENGTH / 2));
    this.y = size.height;
    this.maxY = (size.height / 2) - 4;
  }
}

//todo------------------------------------SIXTH NOTE-----------------------------------

class SixNote extends SpriteComponent {

  bool explode = false;
  double maxY;

  SixNote() : super.rectangle(NOTE_SIZE_LENGTH, NOTE_SIZE_HEIGHT, 'white_box_yellow-01.png');

  @override
  void update(double t) {
    y -= t * SPEED;
  }

  @override
  bool destroy() {

    if (explode) {
      return true;
    }
    if (y == null || maxY == null) {
      return false;
    }
    bool destroy = y <= maxY + NOTE_SIZE_LENGTH;
    if (destroy) {
      //points -= MISS_DEDUCTION;
      //Flame.audio.play('miss.mp3');
    }

    return destroy;
  }

  @override
  void resize(Size size) {
    this.x = (size.width - (size.width / 6.0) - (NOTE_SIZE_LENGTH / 2));
    this.y = size.height;
    this.maxY = (size.height / 2) - 4;
  }
}
//-------------------------------------------------------------------------------


class Explosion extends AnimationComponent {
  static const TIME = 0.75;

  Explosion(SpriteComponent crate) : super.sequenced(NOTE_SIZE_LENGTH + 20, NOTE_SIZE_HEIGHT + 80, 'explosion.png', 23, textureWidth: 31.0, textureHeight: 31.0) {
    this.x = crate.x;
    this.y = crate.y;
    this.animation.stepTime = TIME / 30;
  }

  bool destroy() {
    return this.animation.isLastFrame;
  }
}


class AllowMultipleGestureRecognizer extends TapGestureRecognizer {
  @override
  void rejectGesture(int pointer) {
    acceptGesture(pointer);
  }
}

/*class Song {

  Notes st;

  Song(){
  }

}*/



/*import 'package:flutter/material.dart';
import 'package:open_rhythm/HomePage.dart';

void main() => runApp(new MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'Flutter Demo',
      theme: new ThemeData(
        primarySwatch: Colors.green,
      ),
      home: new HomePage(),
    );
  }
}*/
