import 'dart:async';
import 'dart:core';
import 'dart:io';
import 'package:flutter/material.dart';
import 'loadingScreen.dart';
import 'message_state.dart';
import 'GamePage.dart';
import 'Chart.dart';

class Transition extends StatefulWidget {
  @override
  LoadingScreenExampleState createState() => LoadingScreenExampleState();
}

class LoadingScreenExampleState extends State<Transition> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: LoadingScreen(
          initializers: <dynamic>[GetChart.getLines],
          navigateToWidget: GamePage(),
          loaderColor: Colors.white,
          image: Image.asset('assets/images/one.jpg', fit: BoxFit.cover,),
          backgroundColor: Colors.black,
          styleTextUnderTheLoader: TextStyle(
              fontSize: 14.0,
              fontWeight: FontWeight.bold,
              color: Colors.lightGreenAccent),
        ));
  }
}

class GetChart{

  static Future getLines(MessageState state) async{
      Chart chrt = new Chart();
      await chrt.parseChart();
      var hello = chrt.getBPM();
      print(hello.length);
      state.setMessage = "Get Ready";
    }

  }


class TimeMessages {
  static Future timer(MessageState state) async {
      await Future.delayed(Duration(seconds: 5), () {
        state.setMessage = "Get Ready";
      });
  }
}