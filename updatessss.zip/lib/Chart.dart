import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'dart:async' show Future;
import 'package:flutter/services.dart' show rootBundle;

class Chart
{
  var myFile;
  var isDone = false;
  var resolution = 192;
  List<List<int>> noteList = new List();
  List<List<int>> bpmChanges = new List();

  Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }

  Future<File> get _localFile async {
    //final path = await _localPath;
    final path = await rootBundle.loadString('assets/files/notes.chart');
    return File(path);
  }

  String ltrim(String str) {
    return str.replaceFirst(new RegExp(r"^\s+"), "");
  }


  parseChart() async {

      var isParsingSong = false;
      var isParsingSyncTrack = false;
      var isParsingExpertSingle = false;

      try {
         String chartString = await rootBundle.loadString(
            'assets/files/notes.chart');

        List<String> linesOfChart = chartString.split("\n");

        for (int i = 0; i < 1; i++) {

          String contents = ltrim(linesOfChart[i].toString().toLowerCase());
          print(contents);
          print(contents == "[song]");

          if (contents == "[Song]") {
            isParsingSong = true;
            print("SONG " + isParsingSong.toString());
          }
          else if (isParsingSong) {
            print("SONG" + isParsingSong.toString());
            if (contents == "}") {
              isParsingSong = false;
            }
            else if (contents != "{") {
              var splitContents = contents.split(" ");
              if (splitContents[0] == "Resolution") {
                resolution = int.parse(splitContents[2]);
              }
            }
          }
          else if (contents == "[SyncTrack]")
            isParsingSyncTrack = true;
          else if (isParsingSyncTrack) {
            print("SYNC" + isParsingSyncTrack.toString());
            if (contents == "}") {
              isParsingSyncTrack = false;
            }
            else if (contents != "{") {
              var splitContents = contents.split(" ");
              if (splitContents[2] == "B")
                bpmChanges.add(
                    [int.parse(splitContents[0]), int.parse(splitContents[3])]);
            }
          }
          else if (contents == "[ExpertSingle]")
            isParsingExpertSingle = true;
          else if (isParsingExpertSingle) {
            print("EXPERT" + isParsingExpertSingle.toString());
            if (contents == "}") {
              isParsingExpertSingle = false;
              return;
            }
            else if (contents != "{") {
              var splitContents = contents.split(" ");
              if (splitContents[2] == "N") {
                noteList.add(
                    [int.parse(splitContents[0]), int.parse(splitContents[3])]);
              }
            }
          }
        }

        isDone = true;
    }
      catch (e) {
        //DONOTHING
      }
    }

    List<List<int>> getNoteList() {
      return noteList;
    }

    List<List<int>> getBPM() {
      return bpmChanges;
    }
}